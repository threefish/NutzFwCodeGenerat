package #[base.servicePackage];

import #[base.entityPackage].#[base.entityName];
import com.nutzfw.service.BaseService;
/**
 * @author #[base.userName] #[base.userMail]
 * @date #[date(), dateFormat="yyyy年MM月dd日"]
 * #[base.funName]
 */
public interface #[base.serviceFileName] extends BaseService<#[base.entityName]>{}
