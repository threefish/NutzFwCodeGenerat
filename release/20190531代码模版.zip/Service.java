package #[base.servicePackage];

import #[base.entityPackage].#[base.entityName];
import com.nutzfw.service.BaseService;
/**
 * @author #[base.user] xxx@qq.com
 * @date #[date(), dateFormat="yyyy年MM月dd日 HH时mm分ss秒"]
 */
public interface #[base.serviceFileName] extends BaseService<#[base.entityName]>{}
